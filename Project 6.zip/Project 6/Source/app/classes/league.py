class League:
    def __init__(self, name):
        self.name = name
        self.teams = []