import os
import pickle

from PyQt5.QtWidgets import QMainWindow, QListWidgetItem, QFileDialog
from PyQt5.uic import loadUi

from forms.league_editor_window import LeagueEditorWindow

from classes.league import League 

class MainWindow(QMainWindow):
    def __init__(self, parent=None):
        super().__init__(parent)

        self._leagues = []
        # Loading the UI
        ui_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "ui/main_window.ui")
        loadUi(ui_path, self)
        # Connecting the buttons
        self.actionLoad.triggered.connect(self.loadFile)
        self.actionSave.triggered.connect(self.saveFile)
        self.addPushButton.clicked.connect(self.addLeague)
        self.deletePushButton.clicked.connect(self.deleteLeague)
        self.editPushButton.clicked.connect(self.editLeague)

    def loadFile(self):
        fileName, _ = QFileDialog.getOpenFileName(self, "Load database", "", "Database files (*.database);; All files (*)")
        if fileName:
            with open(fileName, 'rb') as f:
                self._leagues = pickle.load(f)
            self.leaguesListWidget.clear()
            for league in self._leagues:
                self.leaguesListWidget.addItem(QListWidgetItem(league.name))

    def saveFile(self):
        fileName, _ = QFileDialog.getSaveFileName(self, "Save database", "", "Database files (*.database);; All files (*)")
        if fileName:
            with open(fileName, 'wb') as f:
                pickle.dump(self._leagues, f)

    def addLeague(self):
        # Removing extra whitespace
        newLeagueName = self.leagueNameEdit.text().strip()
        if newLeagueName != "":
            # Adding new league
            self.leaguesListWidget.addItem(QListWidgetItem(newLeagueName))
            self._leagues.append(League(newLeagueName))

    def deleteLeague(self):
        currentRow = self.leaguesListWidget.currentRow()
        if currentRow >= 0:
            self.leaguesListWidget.takeItem(self.leaguesListWidget.currentRow())
            del self._leagues[currentRow]

    def editLeague(self):
        currentRow = self.leaguesListWidget.currentRow()
        if currentRow >= 0:
            self._leagueEditorWindow = LeagueEditorWindow(self._leagues[currentRow])
            self._leagueEditorWindow.show()
