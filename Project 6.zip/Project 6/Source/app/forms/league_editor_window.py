import os
import pickle

from PyQt5.QtWidgets import QMainWindow, QListWidgetItem, QFileDialog
from PyQt5.uic import loadUi

from forms.team_editor_window import TeamEditorWindow

from classes.team import Team

class LeagueEditorWindow(QMainWindow):
    def __init__(self, league, parent=None):
        super().__init__(parent)

        self._league = league
        # Loading the UI
        ui_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "ui/league_editor.ui")
        loadUi(ui_path, self)
        # Connecting the buttons
        self.actionImport.triggered.connect(self.importTeam)
        self.actionExport.triggered.connect(self.exportTeam)
        self.addPushButton.clicked.connect(self.addTeam)
        self.deletePushButton.clicked.connect(self.deleteTeam)
        self.editPushButton.clicked.connect(self.editTeam)
        # Loading teams
        self._loadTeams()

    def _loadTeams(self):
        self.teamsListWidget.clear()
        for team in self._league.teams:
            self.teamsListWidget.addItem(QListWidgetItem(team.name))


    def importTeam(self):
        fileName, _ = QFileDialog.getOpenFileName(self, "Import league", "", "League files (*.league);; All files (*)")
        if fileName:
            with open(fileName, 'rb') as f:
                self._league = pickle.load(f)
            self._loadTeams()

    def exportTeam(self):
        fileName, _ = QFileDialog.getSaveFileName(self, "Export league", "", "League files (*.league);; All files (*)")
        if fileName:
            with open(fileName, 'wb') as f:
                pickle.dump(self._league, f)

    def addTeam(self):
        # Removing extra whitespace
        newTeamName = self.teamNameEdit.text().strip()
        if newTeamName != "":
            # Adding new team
            self.teamsListWidget.addItem(QListWidgetItem(newTeamName))
            self._league.teams.append(Team(newTeamName))

    def deleteTeam(self):
        currentRow = self.teamsListWidget.currentRow()
        if currentRow >= 0:
            self.teamsListWidget.takeItem(self.teamsListWidget.currentRow())
            del self._league.teams[currentRow]

    def editTeam(self):
        currentRow = self.teamsListWidget.currentRow()
        if currentRow >= 0:
            self._teamEditorWindow = TeamEditorWindow(self._league.teams[currentRow])
            self._teamEditorWindow.show()
