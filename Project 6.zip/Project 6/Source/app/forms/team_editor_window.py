import os
import pickle

from PyQt5.QtWidgets import QMainWindow, QListWidgetItem, QFileDialog
from PyQt5.uic import loadUi

from classes.member import Member

class TeamEditorWindow(QMainWindow):
    def __init__(self, team, parent=None):
        super().__init__(parent)

        self._team = team
        # Loading the UI
        ui_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "ui/team_editor.ui")
        loadUi(ui_path, self)
        # Connecting the buttons
        self.addPushButton.clicked.connect(self.addMember)
        self.deletePushButton.clicked.connect(self.deleteMember)
        self.updatePushButton.clicked.connect(self.updateMember)
        # Loading members
        self._loadMembers()

    def _loadMembers(self):
        self.membersListWidget.clear()
        for member in self._team.members:
            self.membersListWidget.addItem(QListWidgetItem(member.name+" "+member.email))

    def addMember(self):
        # Removing extra whitespace
        newMemberName = self.nameEdit.text().strip()
        newMemberEmail = self.emailEdit.text().strip()
        if newMemberName != "" and newMemberEmail != "":
            # Adding new member
            self.membersListWidget.addItem(QListWidgetItem(newMemberName+" "+newMemberEmail))
            self._team.members.append(Member(newMemberName, newMemberEmail))

    def deleteMember(self):
        currentRow = self.membersListWidget.currentRow()
        if currentRow >= 0:
            self.membersListWidget.takeItem(self.membersListWidget.currentRow())
            del self._team.members[currentRow]

    def updateMember(self):
        currentRow = self.membersListWidget.currentRow()
        newMemberName = self.nameEdit.text().strip()
        newMemberEmail = self.emailEdit.text().strip()
        if currentRow >= 0 and newMemberName != "" and newMemberEmail != "":
            self._team.members[currentRow] = Member(newMemberName, newMemberEmail)
            self.membersListWidget.currentItem().setText(newMemberName+" "+newMemberEmail)
