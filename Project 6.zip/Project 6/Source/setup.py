import sys
from distutils.dir_util import copy_tree

# Installs application on the path given in the first command-line argument
path = sys.argv[1]
copy_tree("app", path)

print("Program installed to "+path)